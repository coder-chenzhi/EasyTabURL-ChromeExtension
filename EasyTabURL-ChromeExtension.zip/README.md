# EasyTabURL-ChromeExtension
Help you operate tabs' url more conveniently

## Features
- get all tabs' urls
- copy all tabs' urls to clipboard(Chrome only!)
- save all tabs' urls to local file
- read local file and open all urls in the file(file generated from 'save' function)

